#!/usr/bin/env python
# coding: utf-8

# In[ ]:


def addition(a,b):
    result= a+b
    return result

