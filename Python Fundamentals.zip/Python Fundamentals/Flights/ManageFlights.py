#!/usr/bin/env python
# coding: utf-8

# In[1]:


def add(a):
    print(a, "no of flights")


# In[ ]:




